use crate::jre::JavaRuntime;
use crate::manifest::{ProfileSpec, ProjectManifest};
use crate::mc_install::{install_game, InstallProgress};
use md5::{Digest, Md5};
use serde::{Deserialize, Serialize};
use std::{
    fs,
    path::{Path, PathBuf},
    process::Command,
};
use thiserror::Error;

#[derive(Debug, Error)]
pub enum LauncherError {
    #[error("java not found")]
    JavaNotFound,
    #[error("io error: {0}")]
    Io(#[from] std::io::Error),
    #[error("instance directory not prepared")]
    InstanceNotPrepared,
    #[error("unsupported loader: {0}")]
    UnsupportedLoader(String),
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct LaunchOptions {
    pub profile_id: String,
    pub instance_dir: PathBuf,
    pub memory_mb: u32,
    pub jvm_args: Vec<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct LaunchResult {
    pub exit_code: Option<i32>,
    pub log_path: PathBuf,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct PreparedInstance {
    pub instance_dir: PathBuf,
    pub mods_dir: PathBuf,
    pub config_dir: PathBuf,
    pub log_dir: PathBuf,
}

pub struct TestLauncher;

/// Computes a deterministic offline-mode UUID from a player name, the same
/// way vanilla Minecraft/most launchers do for offline play: MD5 of
/// `"OfflinePlayer:{name}"`, with the version/variant bits patched to make
/// it a valid (version 3) UUID.
///
/// This matters because the previous implementation always launched with a
/// fixed all-zero UUID regardless of player name: every test run looked
/// like the exact same player to Minecraft, which breaks anything that
/// keys per-player state by UUID (playerdata, permissions, whitelists,
/// mods that store player-scoped data) and makes it impossible to test
/// multiplayer-relevant behavior with different names.
pub fn offline_uuid(player_name: &str) -> String {
    let mut hasher = Md5::new();
    hasher.update(b"OfflinePlayer:");
    hasher.update(player_name.as_bytes());
    let mut bytes: [u8; 16] = hasher.finalize().into();

    // Set version (3) and variant (RFC 4122) bits, matching Java's
    // `UUID.nameUUIDFromBytes` used by vanilla for offline players.
    bytes[6] = (bytes[6] & 0x0f) | 0x30;
    bytes[8] = (bytes[8] & 0x3f) | 0x80;

    format!(
        "{:02x}{:02x}{:02x}{:02x}{:02x}{:02x}{:02x}{:02x}{:02x}{:02x}{:02x}{:02x}{:02x}{:02x}{:02x}{:02x}",
        bytes[0], bytes[1], bytes[2], bytes[3], bytes[4], bytes[5], bytes[6], bytes[7],
        bytes[8], bytes[9], bytes[10], bytes[11], bytes[12], bytes[13], bytes[14], bytes[15],
    )
}

impl TestLauncher {
    /// Returns the newest installed Java runtime, with no regard for what
    /// any particular Minecraft version needs. Prefer
    /// [`Self::find_java_for_minecraft`] when a target version is known;
    /// this is kept only for callers that generically need "some" JVM.
    pub fn find_java() -> Result<JavaRuntime, LauncherError> {
        crate::jre::find_all_runtimes()
            .map_err(|_| LauncherError::JavaNotFound)?
            .into_iter()
            .next()
            .ok_or(LauncherError::JavaNotFound)
    }

    /// Picks the installed Java runtime that best matches what
    /// `mc_version` actually requires (see [`crate::jre::required_java_major`]),
    /// instead of always grabbing the newest JVM on the system regardless
    /// of compatibility. Falls back to the newest available runtime if
    /// nothing meets the requirement, since attempting the launch with a
    /// clear log message is more useful than refusing to start.
    pub fn find_java_for_minecraft(mc_version: &str) -> Result<JavaRuntime, LauncherError> {
        let runtimes = crate::jre::find_all_runtimes().map_err(|_| LauncherError::JavaNotFound)?;
        let required = crate::jre::required_java_major(mc_version);
        crate::jre::find_runtime_for(&runtimes, required).ok_or(LauncherError::JavaNotFound)
    }

    pub fn prepare_instance(
        manifest: &ProjectManifest,
        profile: &ProfileSpec,
        base_instance_dir: impl AsRef<Path>,
    ) -> Result<PreparedInstance, LauncherError> {
        let instance_dir = base_instance_dir.as_ref().join(&profile.id);
        let mods_dir = instance_dir.join("mods");
        let config_dir = instance_dir.join("config");
        let log_dir = instance_dir.join("logs");

        fs::create_dir_all(&mods_dir)?;
        fs::create_dir_all(&config_dir)?;
        fs::create_dir_all(&log_dir)?;

        // For MVP, copy only mods whose side is compatible with the profile side.
        for module in &manifest.mods {
            if !module.side.is_compatible_with_profile(profile.side) {
                continue;
            }
            if let Some(file_name) = &module.file_name {
                let src = PathBuf::from("mods").join(file_name);
                if src.is_file() {
                    fs::copy(&src, mods_dir.join(file_name))?;
                }
            }
        }

        // Copy overrides/config if configured.
        if let Some(overrides) = &manifest.overrides {
            if let Some(config_override) = &overrides.config {
                let src = PathBuf::from(config_override);
                if src.is_dir() {
                    copy_dir_all(&src, &config_dir)?;
                }
            }
        }

        Ok(PreparedInstance {
            instance_dir,
            mods_dir,
            config_dir,
            log_dir,
        })
    }

    pub fn build_command(
        manifest: &ProjectManifest,
        profile: &ProfileSpec,
        options: &LaunchOptions,
        java: &JavaRuntime,
        launcher_dir: &Path,
        progress: &InstallProgress,
    ) -> Result<(std::process::Command, PathBuf), LauncherError> {
        if !options.instance_dir.exists() {
            return Err(LauncherError::InstanceNotPrepared);
        }

        let loader_kind = format!("{:?}", manifest.loader.kind).to_lowercase();
        let loader_version = manifest.loader.version.clone();
        progress.log(&format!("# Loader: {loader_kind} {loader_version}"));

        let game = install_game(
            &manifest.minecraft.version,
            &loader_kind,
            &loader_version,
            launcher_dir,
            Path::new(&java.path),
            progress,
        )
        .map_err(|e| LauncherError::Io(std::io::Error::new(std::io::ErrorKind::Other, e.to_string())))?;

        let auth_player_name = profile
            .player_name
            .as_deref()
            .filter(|name| !name.trim().is_empty())
            .unwrap_or("Player")
            .to_string();
        let auth_uuid = offline_uuid(&auth_player_name);
        let auth_access_token = "0";
        let user_type = "msa";
        let version_type = "release";
        let assets_dir = canonicalize(&game.asset_dir).unwrap_or_else(|_| game.asset_dir.clone());
        let game_dir = canonicalize(&options.instance_dir).unwrap_or_else(|_| options.instance_dir.clone());
        let natives_dir = canonicalize(&game.natives_dir).unwrap_or_else(|_| game.natives_dir.clone());
        let version_jar = canonicalize(&game.client_jar).unwrap_or_else(|_| game.client_jar.clone());
        let library_dir = canonicalize(&launcher_dir.join("libraries"))
            .unwrap_or_else(|_| launcher_dir.join("libraries"));
        let assets_dir_s = assets_dir.to_string_lossy();
        let game_dir_s = game_dir.to_string_lossy();
        let natives_dir_s = natives_dir.to_string_lossy();
        let version_jar_s = version_jar.to_string_lossy();
        let library_dir_s = library_dir.to_string_lossy();

        let classpath = classpath_string(&game.libraries);
        // Same separator `classpath_string`/`std::env::join_paths` uses
        // for `${classpath}`, needed for Forge's `-p <module-path>` JVM
        // arg which uses a separate `${classpath_separator}` placeholder.
        // This was never substituted before, so on Linux/macOS the
        // literal string "${classpath_separator}" ended up inside the
        // module path, which made every entry after the first
        // unresolvable and crashed `securejarhandler`'s module
        // initialization with `InaccessibleObjectException` instead of
        // launching Forge.
        let classpath_separator = if cfg!(target_os = "windows") { ";" } else { ":" };

        progress.log(&format!("# Main class: {}", game.main_class));
        progress.log(&format!("# Classpath entries: {}", game.libraries.len()));

        let mut cmd = Command::new(PathBuf::from(&java.path));
        cmd.arg(format!("-Xmx{}M", options.memory_mb));
        cmd.args(&options.jvm_args);

        for arg in &game.jvm_args {
            let value = arg
                .replace("${natives_directory}", &natives_dir_s)
                .replace("${library_directory}", &library_dir_s)
                .replace("${launcher_name}", "tuffbox")
                .replace("${launcher_version}", "0.1.0")
                .replace("${version_name}", &game.id)
                .replace("${classpath_separator}", classpath_separator)
                .replace("${classpath}", &classpath);
            cmd.arg(value);
        }

        if let Some(log_config) = &game.log_config {
            if let Ok(log_path) = canonicalize(log_config) {
                let log_arg = format!("-Dlog4j.configurationFile={}", log_path.to_string_lossy());
                cmd.arg(log_arg);
            }
        }

        cmd.arg(format!("-Djava.library.path={}", natives_dir_s));
        cmd.arg("-cp").arg(classpath);
        cmd.arg(&game.main_class);

        for arg in &game.game_args {
            let value = arg
                .replace("${auth_player_name}", &auth_player_name)
                .replace("${auth_uuid}", &auth_uuid)
                .replace("${auth_access_token}", auth_access_token)
                .replace("${user_type}", user_type)
                .replace("${version_type}", version_type)
                .replace("${assets_root}", &assets_dir_s)
                .replace("${assets_index_name}", &game.asset_index_id)
                .replace("${game_directory}", &game_dir_s)
                .replace("${version_name}", &game.id)
                .replace("${natives_directory}", &natives_dir_s)
                .replace("${client_jar}", &version_jar_s);
            cmd.arg(value);
        }

        let log_path = options.instance_dir.join("logs").join("latest.log");
        fs::create_dir_all(log_path.parent().unwrap())?;

        cmd.current_dir(&options.instance_dir);

        Ok((cmd, log_path))
    }
}

fn classpath_string(paths: &[PathBuf]) -> String {
    let canonical_paths = paths
        .iter()
        .filter_map(|p| canonicalize(p).ok())
        .collect::<Vec<_>>();

    std::env::join_paths(canonical_paths.iter().map(|p| p.as_os_str()))
        .map(|joined| joined.to_string_lossy().to_string())
        .unwrap_or_else(|_| {
            let separator = if cfg!(target_os = "windows") { ";" } else { ":" };
            canonical_paths
                .iter()
                .map(|p| p.to_string_lossy().to_string())
                .collect::<Vec<_>>()
                .join(separator)
        })
}

fn canonicalize(path: &Path) -> Result<PathBuf, LauncherError> {
    let path = fs::canonicalize(path)?;
    Ok(PathBuf::from(path.to_string_lossy().trim_start_matches("\\\\?\\")))
}

fn copy_dir_all(src: impl AsRef<Path>, dst: impl AsRef<Path>) -> Result<(), LauncherError> {
    fs::create_dir_all(&dst)?;
    for entry in fs::read_dir(src)? {
        let entry = entry?;
        let path = entry.path();
        let dest = dst.as_ref().join(entry.file_name());
        if path.is_dir() {
            copy_dir_all(&path, &dest)?;
        } else {
            fs::copy(&path, &dest)?;
        }
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn finds_java_in_path() {
        // This test only verifies the function does not panic when java is available.
        let result = TestLauncher::find_java();
        if let Ok(java) = result {
            assert!(PathBuf::from(&java.path).exists());
            assert!(java.major >= 8);
        }
    }

    #[test]
    fn offline_uuid_matches_known_vanilla_value() {
        // This is the well-known offline UUID vanilla Minecraft computes
        // for the player name "Notch" (MD5("OfflinePlayer:Notch") with
        // version/variant bits patched). Matching it exactly proves TuffBox
        // computes offline identities the same way the game does.
        assert_eq!(offline_uuid("Notch"), "b50ad385829d3141a2167e7d7539ba7f");
    }

    #[test]
    fn offline_uuid_is_deterministic_per_name() {
        assert_eq!(offline_uuid("Steve"), offline_uuid("Steve"));
        assert_ne!(offline_uuid("Steve"), offline_uuid("Alex"));
    }
}
